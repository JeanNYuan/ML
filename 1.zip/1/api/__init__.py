# -*- coding: utf-8 -*-
def formatted_output(_status, _text, _data):
    return {"status": _status, "msg": _text, "data": _data}